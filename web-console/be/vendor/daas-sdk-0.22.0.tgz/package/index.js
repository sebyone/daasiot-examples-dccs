'use strict';

const path = require('node:path');

const bindingPath = path.join(__dirname, 'build', 'Release', 'daas.node');
const libraryPath = path.join(__dirname, 'lib', 'libdaas.so');

function loadBinding() {
  if (process.platform !== 'linux') {
    throw new Error('daas-sdk@0.22.0 currently supports Linux x64 only.');
  }

  return require(bindingPath);
}

function loadLibrary(customPath = process.env.DAASIOT_LIB || libraryPath) {
  const { DaasIoT } = loadBinding();
  const loaded = DaasIoT.loadLibrary(customPath);
  if (!loaded) {
    throw new Error(`Unable to load the DaaS native library from ${customPath}.`);
  }
  return { DaasIoT, libraryPath: DaasIoT.getLibraryPath() };
}

const api = {
  DriverTypes: Object.freeze({
    NONE: 0,
    DaaS: 1,
    INET4: 2,
    MQTT5: 3,
    UART: 4,
  }),
  bindingPath,
  libraryPath,
  loadBinding,
  loadLibrary,
};

Object.defineProperty(api, 'DaasIoT', {
  enumerable: true,
  get() {
    return loadBinding().DaasIoT;
  },
});

module.exports = api;
