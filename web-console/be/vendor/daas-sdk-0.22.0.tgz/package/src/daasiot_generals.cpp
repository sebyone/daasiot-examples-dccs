/*
 * DaaS-IoT 2019, 2026 (@) Sebyone Srl
 *
 * This Source Code Form is subject to the terms of the Mozilla Public License, v.2.0.
 * If a copy of the MPL was not distributed with this file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

#include "daasjs.h"

Napi::Value DaasIotJs::doInit(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 2 || !info[0].IsNumber() || !info[1].IsNumber()) {
        Napi::TypeError::New(env, "Attesi 2 argomenti: sid, din").ThrowAsJavaScriptException();
        return env.Null();
    }
    din_t sid = (din_t)info[0].As<Napi::Number>().Int64Value();
    din_t din = (din_t)info[1].As<Napi::Number>().Int64Value();
    return Napi::Boolean::New(env, _daasInstance->doInit(sid, din) == ERROR_NONE);
}

Napi::Value DaasIotJs::doPerform(const Napi::CallbackInfo &info)
{
    return Napi::Boolean::New(info.Env(), _daasInstance->doPerform(PERFORM_CORE_THREAD) == ERROR_NONE);
}

Napi::Value DaasIotJs::doEnd(const Napi::CallbackInfo &info)
{
    const bool stopped = _daasInstance->doEnd() == ERROR_NONE;
    releaseEventCallbacks();
    return Napi::Boolean::New(info.Env(), stopped);
}

Napi::Value DaasIotJs::doReset(const Napi::CallbackInfo &info)
{
    return Napi::Boolean::New(info.Env(), _daasInstance->doReset() == ERROR_NONE);
}
