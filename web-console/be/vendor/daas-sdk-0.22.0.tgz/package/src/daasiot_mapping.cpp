/*
 * DaaS-IoT 2019, 2026 (@) Sebyone Srl
 *
 * This Source Code Form is subject to the terms of the Mozilla Public License, v.2.0.
 * If a copy of the MPL was not distributed with this file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

#include "daasjs.h"

Napi::Value DaasIotJs::map(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();

    if (info.Length() == 1 && info[0].IsNumber()) {
        din_t din = (din_t)info[0].As<Napi::Number>().Int64Value();
        return Napi::Boolean::New(env, _daasInstance->map(din) == ERROR_NONE);
    }

    if (info.Length() >= 3 && info[0].IsNumber() && info[1].IsNumber() && info[2].IsString()) {
        din_t       din  = (din_t)info[0].As<Napi::Number>().Int64Value();
        link_t      link = static_cast<link_t>(info[1].As<Napi::Number>().Uint32Value());
        std::string uri  = info[2].As<Napi::String>().Utf8Value();

        if (info.Length() >= 4 && info[3].IsString()) {
            std::string skey = info[3].As<Napi::String>().Utf8Value();
            return Napi::Boolean::New(env, _daasInstance->map(din, link, uri.c_str(), skey.c_str()) == ERROR_NONE);
        }
        return Napi::Boolean::New(env, _daasInstance->map(din, link, uri.c_str()) == ERROR_NONE);
    }

    Napi::TypeError::New(env, "map(din) oppure map(din, link, uri[, skey])").ThrowAsJavaScriptException();
    return env.Null();
}

Napi::Value DaasIotJs::remove(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1 || !info[0].IsNumber()) {
        Napi::TypeError::New(env, "Atteso 1 argomento: din").ThrowAsJavaScriptException();
        return env.Null();
    }
    din_t din = (din_t)info[0].As<Napi::Number>().Int64Value();
    return Napi::Boolean::New(env, _daasInstance->remove(din) == ERROR_NONE);
}
