/*
 * DaaS-IoT 2019, 2026 (@) Sebyone Srl
 *
 * This Source Code Form is subject to the terms of the Mozilla Public License, v.2.0.
 * If a copy of the MPL was not distributed with this file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

#include "daasjs.h"

Napi::Value DaasIotJs::pull(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    bool result = false;

    din_t          din      = (din_t)info[0].As<Napi::Number>().Int64Value();
    Napi::Function callback = info[1].As<Napi::Function>();

    if (pullDDO != nullptr) {
        pullDDO.Release();
        pullDDO = Napi::ThreadSafeFunction();
    }
    pullDDO = Napi::ThreadSafeFunction::New(
        env, callback, "pull", 0, 1, [](Napi::Env) {});
    pullDDO.Unref(env);

    DDO *inboundDDO = nullptr;
    if (_daasInstance->pull(din, &inboundDDO) == ERROR_NONE && inboundDDO != nullptr) {
        uint32_t payloadSize = inboundDDO->getPayloadSize();
        uint8_t *data        = new uint8_t[payloadSize];
        inboundDDO->getPayloadAsBinary(data, 0, payloadSize);

        pullDDO.NonBlockingCall(
            new PullCallbackParams{
                inboundDDO->getOrigin(),
                inboundDDO->getTimestamp(),
                inboundDDO->getTypeset(),
                data,
                payloadSize
            },
            [](Napi::Env env, Napi::Function jsCallback, PullCallbackParams *params) {
                jsCallback.Call({
                    Napi::Number::New(env, (double)params->origin),
                    Napi::Number::New(env, (double)params->timestamp),
                    Napi::Number::New(env, params->typeset),
                    Napi::Buffer<uint8_t>::Copy(env, params->data, params->dataLength),
                });
                delete[] params->data;
                delete params;
            });
        result = true;
    }

    pullDDO.Release();
    pullDDO = Napi::ThreadSafeFunction();
    return Napi::Boolean::New(env, result);
}

Napi::Value DaasIotJs::push(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 4 || !info[0].IsNumber() || !info[1].IsNumber() ||
        !info[2].IsNumber() || !info[3].IsString()) {
        Napi::TypeError::New(env, "Attesi 4 argomenti: din, typeset, timestamp, payload").ThrowAsJavaScriptException();
        return env.Null();
    }
    din_t       din       = (din_t)info[0].As<Napi::Number>().Int64Value();
    typeset_t   typeset   = (typeset_t)info[1].As<Napi::Number>().Uint32Value();
    stime_t     timestamp = (stime_t)info[2].As<Napi::Number>().Int64Value();
    std::string payload   = info[3].As<Napi::String>().Utf8Value();

    DDO outboundDDO(typeset);
    outboundDDO.setPayload(payload.c_str(), payload.size());
    return Napi::Boolean::New(env, _daasInstance->push(din, &outboundDDO) == ERROR_NONE);
}
