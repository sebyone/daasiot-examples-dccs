#include "dtojs.h"

Napi::Value Dtojs::make(const Napi::CallbackInfo &info){

    Napi::Env env = info.Env();
    
    std::string payloadStr;
    Napi::Object obj = Napi::Object::New(info.Env());

    // Typeset
    if(obj.Has("typeset"))
    {
      Napi::Value typeset = obj.Get("typeset");
      setTypeset(typeset.ToNumber().Uint32Value());
    }
    // Payload
    if(obj.Has("payload"))
    {
      Napi::Value payload = obj.Get("payload");
      payloadStr = payload.ToString();
      setPayload(payloadStr.c_str(), payloadStr.size());
    }


    Napi::Number result = Napi::Number::New(env, 11);
    Napi::String uid = Napi::String::New(env, "11IIXPRTKKIYAGH");
    // Call function with arguments
    onComplete.Call({result, uid});
    return env.Undefined();
  }
  