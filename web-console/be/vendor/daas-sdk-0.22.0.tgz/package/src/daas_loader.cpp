/*
 * DaaS-IoT 2026 (@) Sebyone Srl
 *
 * File: daas_loader.cpp
 *
 * This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
 * If a copy of the MPL was not distributed with this file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

#include "daas_loader.h"

#ifdef _WIN32
#   include <windows.h>
    using lib_handle_t = HMODULE;
    static lib_handle_t lib_open(const char *path) { return LoadLibraryA(path); }
    static void         lib_close(lib_handle_t h)  { FreeLibrary(h); }
    static std::string  lib_error()
    {
        DWORD code = GetLastError();
        char buf[256] = {};
        FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                       nullptr, code, 0, buf, sizeof(buf), nullptr);
        return std::string(buf);
    }
#else
#   include <dlfcn.h>
    using lib_handle_t = void *;
    // RTLD_GLOBAL makes the exported C++ symbols visible process-wide so that
    // DaasAPI vtable / constructors are resolved when new DaasIoT() is called.
    static lib_handle_t lib_open(const char *path) { return dlopen(path, RTLD_NOW | RTLD_GLOBAL); }
    static void         lib_close(lib_handle_t h)  { dlclose(h); }
    static std::string  lib_error()
    {
        const char *e = dlerror();
        return e ? std::string(e) : "unknown error";
    }
#endif

// --- static members ---
void       *DaasLoader::_handle    = nullptr;
std::string DaasLoader::_path;
std::string DaasLoader::_lastError;

bool DaasLoader::load(const std::string &path)
{
    // Close any previously loaded handle
    if (_handle) {
        lib_close(static_cast<lib_handle_t>(_handle));
        _handle = nullptr;
        _path.clear();
    }

    // Clear previous error
    dlerror(); // on POSIX, clears pending error

    lib_handle_t h = lib_open(path.c_str());
    if (!h) {
        _lastError = lib_error();
        return false;
    }

    _handle    = static_cast<void *>(h);
    _path      = path;
    _lastError.clear();
    return true;
}

bool DaasLoader::isLoaded()
{
    return _handle != nullptr;
}

std::string DaasLoader::getPath()
{
    return _path;
}

std::string DaasLoader::getLastError()
{
    return _lastError;
}
