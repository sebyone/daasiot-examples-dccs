/*
 * DaaS-IoT 2019, 2026 (@) Sebyone Srl
 *
 * This Source Code Form is subject to the terms of the Mozilla Public License, v.2.0.
 * If a copy of the MPL was not distributed with this file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

#include "daasjs.h"

// No-op handler used when registering a typeset without a per-typeset JS callback.
// DDOs with registered typesets must be received via onDDOReceived instead.
static void noop_typeset_handler(din_t) {}

Napi::Object DaasIotJs::Init(Napi::Env env, Napi::Object exports)
{
    napi_property_attributes props =
        static_cast<napi_property_attributes>(napi_writable | napi_configurable);

    Napi::Function func = DefineClass(env, "DaasIoT", {
        // Generals
        InstanceMethod<&DaasIotJs::getVersion>("getVersion", props),
        InstanceMethod<&DaasIotJs::getBuildInfo>("getBuildInfo", props),
        InstanceMethod<&DaasIotJs::doInit>("doInit", props),
        InstanceMethod<&DaasIotJs::doPerform>("doPerform", props),
        InstanceMethod<&DaasIotJs::getChanges>("getChanges", props),
        InstanceMethod<&DaasIotJs::doReset>("doReset", props),
        InstanceMethod<&DaasIotJs::getStatus>("getStatus", props),
        InstanceMethod<&DaasIotJs::listAvailableDrivers>("listAvailableDrivers", props),
        InstanceMethod<&DaasIotJs::enableDriver>("enableDriver", props),
        InstanceMethod<&DaasIotJs::setOptions>("setOptions", props),
        InstanceMethod<&DaasIotJs::doStatisticsReset>("doStatisticsReset", props),
        InstanceMethod<&DaasIotJs::getSystemStatistics>("getSystemStatistics", props),
        InstanceMethod<&DaasIotJs::doEnd>("doEnd", props),
        InstanceMethod<&DaasIotJs::errorToString>("errorToString", props),
        // Mapping / typesets
        InstanceMethod<&DaasIotJs::addTypeset>("addTypeset", props),
        InstanceMethod<&DaasIotJs::typesetList>("typesetList", props),
        // Availability
        InstanceMethod<&DaasIotJs::listNodes>("listNodes", props),
        InstanceMethod<&DaasIotJs::getNodeList>("getNodeList", props),
        InstanceMethod<&DaasIotJs::locate>("locate", props),
        // Network
        InstanceMethod<&DaasIotJs::map>("map", props),
        InstanceMethod<&DaasIotJs::remove>("remove", props),
        InstanceMethod<&DaasIotJs::discovery>("discovery", props),
        InstanceMethod<&DaasIotJs::join>("join", props),
        InstanceMethod<&DaasIotJs::setDiscoveryState>("setDiscoveryState", props),
        InstanceMethod<&DaasIotJs::createNetwork>("createNetwork", props),
        InstanceMethod<&DaasIotJs::unbindNetwork>("unbindNetwork", props),
        InstanceMethod<&DaasIotJs::setAcceptRequestsLevel>("setAcceptRequestsLevel", props),
        // Time / Sync
        InstanceMethod<&DaasIotJs::setATSMaxError>("setATSMaxError", props),
        InstanceMethod<&DaasIotJs::getSyncedTimestamp>("getSyncedTimestamp", props),
        // Transfer
        InstanceMethod<&DaasIotJs::push>("push", props),
        InstanceMethod<&DaasIotJs::pull>("pull", props),
        InstanceMethod<&DaasIotJs::availablesPull>("availablesPull", props),
        InstanceMethod<&DaasIotJs::setDDOPolicy>("setDDOPolicy", props),
        // Streaming
        InstanceMethod<&DaasIotJs::use>("use", props),
        InstanceMethod<&DaasIotJs::send>("send", props),
        InstanceMethod<&DaasIotJs::received>("received", props),
        InstanceMethod<&DaasIotJs::receive>("receive", props),
        InstanceMethod<&DaasIotJs::endStream>("endStream", props),
        // Diagnostics
        InstanceMethod<&DaasIotJs::frisbee>("frisbee", props),
        InstanceMethod<&DaasIotJs::frisbeeICMP>("frisbeeICMP", props),
        // Node features
        InstanceMethod<&DaasIotJs::addNodeFeatures>("addNodeFeatures", props),
        InstanceMethod<&DaasIotJs::getNodeFeatures>("getNodeFeatures", props),
        InstanceMethod<&DaasIotJs::nodeHasFeature>("nodeHasFeature", props),
        // Events
        InstanceMethod<&DaasIotJs::onDinConnected>("onDinConnected", props),
        InstanceMethod<&DaasIotJs::onDDOReceived>("onDDOReceived", props),
        InstanceMethod<&DaasIotJs::onNetworkDiscovered>("onNetworkDiscovered", props),
        // Static loader
        StaticMethod<&DaasIotJs::loadLibrary>("loadLibrary",
            static_cast<napi_property_attributes>(napi_static | napi_writable | napi_configurable)),
        StaticMethod<&DaasIotJs::isLibraryLoaded>("isLibraryLoaded",
            static_cast<napi_property_attributes>(napi_static | napi_writable | napi_configurable)),
        StaticMethod<&DaasIotJs::getLibraryPath>("getLibraryPath",
            static_cast<napi_property_attributes>(napi_static | napi_writable | napi_configurable)),
    });

    Napi::FunctionReference *constructor = new Napi::FunctionReference();
    *constructor = Napi::Persistent(func);
    exports.Set("DaasIoT", func);
    env.SetInstanceData<Napi::FunctionReference>(constructor);
    return exports;
}

DaasIotJs::DaasIotJs(const Napi::CallbackInfo &info) : Napi::ObjectWrap<DaasIotJs>(info)
{
    Napi::Env env = info.Env();
    if (!DaasLoader::isLoaded()) {
        Napi::Error::New(env,
            "libdaas non caricata. Chiamare DaasIoT.loadLibrary(path) prima di creare istanze.")
            .ThrowAsJavaScriptException();
        return;
    }
    if (info.Length() < 1 || !info[0].IsString()) {
        Napi::TypeError::New(env, "1 argomento atteso").ThrowAsJavaScriptException();
        return;
    }
    std::string lhver_ = info[0].As<Napi::String>().Utf8Value();
    _daasInstance = new DaasAPI(this, lhver_.c_str());
}

// --- Version / build info ---

Napi::Value DaasIotJs::getVersion(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    Napi::Object result = Napi::Object::New(env);
    const char *ver = _daasInstance->getVersion();
    const char *bi  = _daasInstance->getBuildInfo();
    result.Set("version",   Napi::String::New(env, ver ? ver : ""));
    result.Set("buildInfo", Napi::String::New(env, bi  ? bi  : ""));
    return result;
}

Napi::Value DaasIotJs::getBuildInfo(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    const char *bi = _daasInstance->getBuildInfo();
    return Napi::String::New(env, bi ? bi : "");
}

// --- Node status ---

Napi::Value DaasIotJs::getStatus(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    node_info_t s = _daasInstance->getStatus();
    Napi::Object obj = Napi::Object::New(env);
    obj.Set("power_on_time",         Napi::Number::New(env, (double)s.power_on_time));
    obj.Set("linked",                Napi::Number::New(env, s.linked));
    obj.Set("lock",                  Napi::Number::New(env, s.lock));
    obj.Set("sklen",                 Napi::Number::New(env, s.sklen));
    obj.Set("skey",                  Napi::String::New(env, std::string(s.skey, s.skey + s.sklen)));
    obj.Set("accept_request_policy", Napi::Number::New(env, (uint32_t)s.accept_request_policy));
    obj.Set("sid",                   Napi::Number::New(env, (double)s.sid));
    obj.Set("din",                   Napi::Number::New(env, (double)s.din));
    obj.Set("ddo_policy",            Napi::Number::New(env, (uint32_t)s.ddo_policy));
    obj.Set("discovery_state",       Napi::Number::New(env, (uint32_t)s.discovery_state));
    obj.Set("oCap_net",              Napi::Number::New(env, (double)s.oCap_net));
    obj.Set("net_in_sync",           Napi::Boolean::New(env, s.net_in_sync));
    return obj;
}

// --- getChanges (stub — parameters are returned by reference in the native API) ---

Napi::Value DaasIotJs::getChanges(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() != 4) {
        Napi::TypeError::New(env, "Attesi 4 argomenti").ThrowAsJavaScriptException();
        return env.Null();
    }
    return Napi::Boolean::New(env, true);
}

// --- Drivers ---

Napi::Value DaasIotJs::enableDriver(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 2) {
        Napi::TypeError::New(env, "Attesi 2 argomenti: driver_id, uri").ThrowAsJavaScriptException();
        return env.Null();
    }
    link_t driver_id = static_cast<link_t>(info[0].As<Napi::Number>().Uint32Value());
    std::string uri  = info[1].As<Napi::String>().Utf8Value();
    return Napi::Boolean::New(env, _daasInstance->enableDriver(driver_id, uri.c_str()) == ERROR_NONE);
}

Napi::Value DaasIotJs::listAvailableDrivers(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    const char *drivers = _daasInstance->listAvailableDrivers();
    return Napi::String::New(env, drivers ? drivers : "");
}

// --- Options / statistics ---

Napi::Value DaasIotJs::setOptions(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 2) {
        Napi::TypeError::New(env, "Attesi 2 argomenti: option, value").ThrowAsJavaScriptException();
        return env.Null();
    }
    option_t option = static_cast<option_t>(info[0].As<Napi::Number>().Uint32Value());
    uint32_t val    = info[1].As<Napi::Number>().Uint32Value();
    return Napi::Boolean::New(env, _daasInstance->setOptions(option, val) == ERROR_NONE);
}

Napi::Value DaasIotJs::doStatisticsReset(const Napi::CallbackInfo &info)
{
    return Napi::Boolean::New(info.Env(), _daasInstance->doStatisticsReset());
}

Napi::Value DaasIotJs::getSystemStatistics(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1) {
        Napi::TypeError::New(env, "Atteso 1 argomento: label").ThrowAsJavaScriptException();
        return env.Null();
    }
    syscode_t label = static_cast<syscode_t>(info[0].As<Napi::Number>().Uint32Value());
    return Napi::Number::New(env, (double)_daasInstance->getSystemStatistics(label));
}

Napi::Value DaasIotJs::errorToString(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1) {
        Napi::TypeError::New(env, "Atteso 1 argomento: error_code").ThrowAsJavaScriptException();
        return env.Null();
    }
    daas_error_t code = static_cast<daas_error_t>(info[0].As<Napi::Number>().Uint32Value());
    const char *s = _daasInstance->errorToString(code);
    return Napi::String::New(env, s ? s : "");
}

// --- Typesets ---

Napi::Value DaasIotJs::addTypeset(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1) {
        Napi::TypeError::New(env, "Atteso 1 argomento: typeset_code").ThrowAsJavaScriptException();
        return env.Null();
    }
    uint16_t code = (uint16_t)info[0].As<Napi::Number>().Uint32Value();
    return Napi::Boolean::New(env, _daasInstance->addTypeset(code, noop_typeset_handler) == ERROR_NONE);
}

Napi::Value DaasIotJs::typesetList(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    typeset_list &tl = _daasInstance->listTypesets();
    Napi::Array result = Napi::Array::New(env, tl.size());
    for (uint32_t i = 0; i < tl.size(); i++)
        result[i] = Napi::Number::New(env, tl[i]);
    return result;
}

// --- Node lists ---

Napi::Value DaasIotJs::listNodes(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    network_info_list_t nodes = _daasInstance->listNodes();
    Napi::Array result = Napi::Array::New(env, nodes.size());
    for (uint32_t i = 0; i < nodes.size(); i++) {
        Napi::Object entry = Napi::Object::New(env);
        entry.Set("sid", Napi::Number::New(env, (double)nodes[i].sid));
        entry.Set("din", Napi::Number::New(env, (double)nodes[i].din));
        result[i] = entry;
    }
    return result;
}

Napi::Value DaasIotJs::getNodeList(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    node_map_list_t nodes = _daasInstance->getNodeList();
    Napi::Array result = Napi::Array::New(env, nodes.size());
    for (uint32_t i = 0; i < nodes.size(); i++) {
        Napi::Object entry = Napi::Object::New(env);
        entry.Set("din",            Napi::Number::New(env, (double)nodes[i].din));
        entry.Set("channel_owner",  Napi::Number::New(env, (double)nodes[i].channel_owner));
        entry.Set("link",           Napi::Number::New(env, (uint32_t)nodes[i].link));
        entry.Set("uri",            Napi::String::New(env, nodes[i].uri));
        entry.Set("direct_channel", Napi::Boolean::New(env, nodes[i].direct_channel));
        result[i] = entry;
    }
    return result;
}

Napi::Value DaasIotJs::locate(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1) {
        Napi::TypeError::New(env, "Atteso almeno 1 argomento: din").ThrowAsJavaScriptException();
        return env.Null();
    }
    din_t din   = (din_t)info[0].As<Napi::Number>().Int64Value();
    int timeout = info.Length() > 1 ? info[1].As<Napi::Number>().Int32Value() : 1000;
    int ttl     = info.Length() > 2 ? info[2].As<Napi::Number>().Int32Value() : 10;
    return Napi::Boolean::New(env, _daasInstance->locate(din, timeout, ttl) == ERROR_NONE);
}

// --- Network management ---

Napi::Value DaasIotJs::discovery(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    daas_error_t err;
    if (info.Length() >= 1 && info[0].IsNumber())
        err = _daasInstance->discovery(static_cast<link_t>(info[0].As<Napi::Number>().Uint32Value()));
    else
        err = _daasInstance->discovery();
    return Napi::Boolean::New(env, err == ERROR_NONE);
}

Napi::Value DaasIotJs::join(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    din_t    sid     = (info.Length() > 0 && info[0].IsNumber()) ? (din_t)info[0].As<Napi::Number>().Int64Value() : 0;
    link_t   link    = (info.Length() > 1 && info[1].IsNumber()) ? static_cast<link_t>(info[1].As<Napi::Number>().Uint32Value()) : _LINK_NONE;
    uint32_t timeout = (info.Length() > 2 && info[2].IsNumber()) ? info[2].As<Napi::Number>().Uint32Value() : 5000;
    return Napi::Boolean::New(env, _daasInstance->join(sid, link, timeout) == ERROR_NONE);
}

Napi::Value DaasIotJs::setDiscoveryState(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1) {
        Napi::TypeError::New(env, "Atteso 1 argomento: mode").ThrowAsJavaScriptException();
        return env.Null();
    }
    _daasInstance->setDiscoveryState(static_cast<discovery_state_t>(info[0].As<Napi::Number>().Uint32Value()));
    return env.Undefined();
}

Napi::Value DaasIotJs::createNetwork(const Napi::CallbackInfo &info)
{
    return Napi::Boolean::New(info.Env(), _daasInstance->createNetwork() == ERROR_NONE);
}

Napi::Value DaasIotJs::unbindNetwork(const Napi::CallbackInfo &info)
{
    return Napi::Boolean::New(info.Env(), _daasInstance->unbindNetwork() == ERROR_NONE);
}

Napi::Value DaasIotJs::setAcceptRequestsLevel(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1) {
        Napi::TypeError::New(env, "Atteso 1 argomento: policy").ThrowAsJavaScriptException();
        return env.Null();
    }
    _daasInstance->setAcceptRequestsLevel(static_cast<accept_request_policy_t>(info[0].As<Napi::Number>().Uint32Value()));
    return env.Undefined();
}

// --- Time / ATS ---

Napi::Value DaasIotJs::setATSMaxError(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1) {
        Napi::TypeError::New(env, "Atteso 1 argomento: error_ms").ThrowAsJavaScriptException();
        return env.Null();
    }
    _daasInstance->setATSMaxError(info[0].As<Napi::Number>().Int32Value());
    return env.Undefined();
}

Napi::Value DaasIotJs::getSyncedTimestamp(const Napi::CallbackInfo &info)
{
    return Napi::Number::New(info.Env(), (double)_daasInstance->getSyncedTimestamp());
}

// --- DDO policy / availability ---

Napi::Value DaasIotJs::setDDOPolicy(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1) {
        Napi::TypeError::New(env, "Atteso 1 argomento: policy").ThrowAsJavaScriptException();
        return env.Null();
    }
    ddo_policy_t policy = static_cast<ddo_policy_t>(info[0].As<Napi::Number>().Uint32Value());
    return Napi::Boolean::New(env, _daasInstance->setDDOPolicy(policy) == ERROR_NONE);
}

Napi::Value DaasIotJs::availablesPull(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1) {
        Napi::TypeError::New(env, "Atteso 1 argomento: din").ThrowAsJavaScriptException();
        return env.Null();
    }
    din_t    din   = (din_t)info[0].As<Napi::Number>().Int64Value();
    uint32_t count = 0;
    _daasInstance->availablesPull(din, count);
    return Napi::Number::New(env, count);
}

// --- Streaming ---

Napi::Value DaasIotJs::use(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1) {
        Napi::TypeError::New(env, "Atteso almeno 1 argomento: din").ThrowAsJavaScriptException();
        return env.Null();
    }
    din_t    din      = (din_t)info[0].As<Napi::Number>().Int64Value();
    uint32_t rx_queue = (info.Length() > 1 && info[1].IsNumber()) ? info[1].As<Napi::Number>().Uint32Value() : 0;
    uint32_t retry    = (info.Length() > 2 && info[2].IsNumber()) ? info[2].As<Napi::Number>().Uint32Value() : 3;
    uint32_t timeout  = (info.Length() > 3 && info[3].IsNumber()) ? info[3].As<Napi::Number>().Uint32Value() : 1000;
    return Napi::Boolean::New(env, _daasInstance->use(din, rx_queue, retry, timeout));
}

Napi::Value DaasIotJs::send(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 2) {
        Napi::TypeError::New(env, "Attesi almeno 2 argomenti: din, data").ThrowAsJavaScriptException();
        return env.Null();
    }
    din_t    din     = (din_t)info[0].As<Napi::Number>().Int64Value();
    uint32_t timeout = (info.Length() > 2 && info[2].IsNumber()) ? info[2].As<Napi::Number>().Uint32Value() : 1000;
    uint32_t retry   = (info.Length() > 3 && info[3].IsNumber()) ? info[3].As<Napi::Number>().Uint32Value() : 3;

    if (info[1].IsBuffer()) {
        Napi::Buffer<uint8_t> buf = info[1].As<Napi::Buffer<uint8_t>>();
        return Napi::Number::New(env, _daasInstance->send(din, buf.Data(), (uint32_t)buf.ByteLength(), timeout, retry));
    }
    if (info[1].IsString()) {
        std::string s = info[1].As<Napi::String>().Utf8Value();
        return Napi::Number::New(env, _daasInstance->send(din, (uint8_t *)s.data(), (uint32_t)s.size(), timeout, retry));
    }
    Napi::TypeError::New(env, "data deve essere Buffer o stringa").ThrowAsJavaScriptException();
    return env.Null();
}

Napi::Value DaasIotJs::received(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1) {
        Napi::TypeError::New(env, "Atteso 1 argomento: din").ThrowAsJavaScriptException();
        return env.Null();
    }
    din_t din = (din_t)info[0].As<Napi::Number>().Int64Value();
    return Napi::Number::New(env, _daasInstance->received(din));
}

Napi::Value DaasIotJs::receive(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1) {
        Napi::TypeError::New(env, "Atteso 1 argomento: din").ThrowAsJavaScriptException();
        return env.Null();
    }
    din_t    din     = (din_t)info[0].As<Napi::Number>().Int64Value();
    uint8_t *inbound = nullptr;
    uint32_t size    = _daasInstance->receive(din, inbound);
    if (size > 0 && inbound != nullptr)
        return Napi::Buffer<uint8_t>::Copy(env, inbound, size);
    return env.Null();
}

Napi::Value DaasIotJs::endStream(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1) {
        Napi::TypeError::New(env, "Atteso 1 argomento: din").ThrowAsJavaScriptException();
        return env.Null();
    }
    din_t din = (din_t)info[0].As<Napi::Number>().Int64Value();
    return Napi::Boolean::New(env, _daasInstance->end(din));
}

// --- Frisbee / diagnostics ---

Napi::Value DaasIotJs::frisbee(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1) {
        Napi::TypeError::New(env, "Atteso 1 argomento: din").ThrowAsJavaScriptException();
        return env.Null();
    }
    din_t din = (din_t)info[0].As<Napi::Number>().Int64Value();
    return Napi::Boolean::New(env, _daasInstance->frisbee(din) == ERROR_NONE);
}

Napi::Value DaasIotJs::frisbeeICMP(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 3) {
        Napi::TypeError::New(env, "Attesi 3 argomenti: din, timeout, retry").ThrowAsJavaScriptException();
        return env.Null();
    }
    din_t    din     = (din_t)info[0].As<Napi::Number>().Int64Value();
    uint32_t timeout = info[1].As<Napi::Number>().Uint32Value();
    uint32_t retry   = info[2].As<Napi::Number>().Uint32Value();
    return Napi::Boolean::New(env, _daasInstance->frisbeeICMP(din, timeout, retry) == ERROR_NONE);
}

// --- Node features ---

Napi::Value DaasIotJs::addNodeFeatures(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1) {
        Napi::TypeError::New(env, "Atteso 1 argomento: features").ThrowAsJavaScriptException();
        return env.Null();
    }
    feature_t features = static_cast<feature_t>(info[0].As<Napi::Number>().Uint32Value());
    return Napi::Boolean::New(env, _daasInstance->addNodeFeatures(features) == ERROR_NONE);
}

Napi::Value DaasIotJs::getNodeFeatures(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    features_list fl = _daasInstance->getNodeFeatures();
    Napi::Array result = Napi::Array::New(env, fl.size());
    for (uint32_t i = 0; i < fl.size(); i++)
        result[i] = Napi::Number::New(env, (uint32_t)fl[i]);
    return result;
}

Napi::Value DaasIotJs::nodeHasFeature(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 2) {
        Napi::TypeError::New(env, "Attesi 2 argomenti: din, feature").ThrowAsJavaScriptException();
        return env.Null();
    }
    din_t     din     = (din_t)info[0].As<Napi::Number>().Int64Value();
    feature_t feature = static_cast<feature_t>(info[1].As<Napi::Number>().Uint32Value());
    return Napi::Boolean::New(env, _daasInstance->nodeHasFeature(din, feature));
}

// --- Static loader methods ---

Napi::Value DaasIotJs::loadLibrary(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    if (info.Length() < 1 || !info[0].IsString()) {
        Napi::TypeError::New(env, "Atteso 1 argomento: path alla libreria condivisa").ThrowAsJavaScriptException();
        return env.Null();
    }
    std::string path = info[0].As<Napi::String>().Utf8Value();
    if (!DaasLoader::load(path)) {
        Napi::Error::New(env, "Impossibile caricare libdaas da '" + path + "': " + DaasLoader::getLastError())
            .ThrowAsJavaScriptException();
        return env.Null();
    }
    return Napi::Boolean::New(env, true);
}

Napi::Value DaasIotJs::isLibraryLoaded(const Napi::CallbackInfo &info)
{
    return Napi::Boolean::New(info.Env(), DaasLoader::isLoaded());
}

Napi::Value DaasIotJs::getLibraryPath(const Napi::CallbackInfo &info)
{
    return Napi::String::New(info.Env(), DaasLoader::getPath());
}
