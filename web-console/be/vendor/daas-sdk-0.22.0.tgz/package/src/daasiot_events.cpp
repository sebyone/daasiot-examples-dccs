/*
 * DaaS-IoT 2019, 2026 (@) Sebyone Srl
 *
 * This Source Code Form is subject to the terms of the Mozilla Public License, v.2.0.
 * If a copy of the MPL was not distributed with this file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

#include "daasjs.h"

static void releaseThreadSafeFunction(Napi::ThreadSafeFunction &callback)
{
    if (callback == nullptr) return;
    callback.Release();
    callback = Napi::ThreadSafeFunction();
}

void DaasIotJs::releaseEventCallbacks()
{
    releaseThreadSafeFunction(onDINAcceptedEvent);
    releaseThreadSafeFunction(onDDOReceivedEvent);
    releaseThreadSafeFunction(onNetworkDiscoveredEvent);
    releaseThreadSafeFunction(pullDDO);
}

void DaasIotJs::dinAccepted(din_t din_)
{
    if (onDINAcceptedEvent == nullptr) return;
    onDINAcceptedEvent.NonBlockingCall(
        new CallbackParams{ (int)din_ },
        [](Napi::Env env, Napi::Function jsCallback, CallbackParams *params) {
            jsCallback.Call({ Napi::Number::New(env, params->din) });
            delete params;
        });
}

void DaasIotJs::ddoReceived(int payload_size, typeset_t typeset_, din_t din_)
{
    if (onDDOReceivedEvent == nullptr) return;
    onDDOReceivedEvent.NonBlockingCall(
        new CallbackParams{ (int)din_ },
        [](Napi::Env env, Napi::Function jsCallback, CallbackParams *params) {
            jsCallback.Call({ Napi::Number::New(env, params->din) });
            delete params;
        });
}

void DaasIotJs::networkDiscovered(din_t din, din_t sid, link_t link)
{
    if (onNetworkDiscoveredEvent == nullptr) return;
    auto *params = new NetworkDiscoveredParams{ din, sid, link };
    onNetworkDiscoveredEvent.NonBlockingCall(
        params,
        [](Napi::Env env, Napi::Function jsCallback, NetworkDiscoveredParams *p) {
            jsCallback.Call({
                Napi::Number::New(env, (double)p->din),
                Napi::Number::New(env, (double)p->sid),
                Napi::Number::New(env, (uint32_t)p->link),
            });
            delete p;
        });
}

void DaasIotJs::frisbeeReceived(din_t)            {}
void DaasIotJs::nodeStateReceived(din_t)          {}
void DaasIotJs::atsSyncCompleted(din_t)           {}
void DaasIotJs::frisbeeDperfCompleted(din_t, uint32_t, uint32_t) {}
void DaasIotJs::nodeConnectedToNetwork(din_t, din_t) {}
void DaasIotJs::streamInfoReceived(din_t, stream_type, uint32_t) {}

// --- JS event registration ---

Napi::Value DaasIotJs::onDinConnected(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    Napi::Function cb = info[0].As<Napi::Function>();
    releaseThreadSafeFunction(onDINAcceptedEvent);
    onDINAcceptedEvent = Napi::ThreadSafeFunction::New(env, cb, "onDinConnected", 0, 1, [](Napi::Env) {});
    onDINAcceptedEvent.Unref(env);
    return Napi::Boolean::New(env, true);
}

Napi::Value DaasIotJs::onDDOReceived(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    Napi::Function cb = info[0].As<Napi::Function>();
    releaseThreadSafeFunction(onDDOReceivedEvent);
    onDDOReceivedEvent = Napi::ThreadSafeFunction::New(env, cb, "onDDOReceived", 0, 1, [](Napi::Env) {});
    onDDOReceivedEvent.Unref(env);
    return Napi::Boolean::New(env, true);
}

Napi::Value DaasIotJs::onNetworkDiscovered(const Napi::CallbackInfo &info)
{
    Napi::Env env = info.Env();
    Napi::Function cb = info[0].As<Napi::Function>();
    releaseThreadSafeFunction(onNetworkDiscoveredEvent);
    onNetworkDiscoveredEvent = Napi::ThreadSafeFunction::New(env, cb, "onNetworkDiscovered", 0, 1, [](Napi::Env) {});
    onNetworkDiscoveredEvent.Unref(env);
    return Napi::Boolean::New(env, true);
}
