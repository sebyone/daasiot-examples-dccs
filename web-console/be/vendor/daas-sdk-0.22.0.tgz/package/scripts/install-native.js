'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const root = path.resolve(__dirname, '..');
const libraryPath = path.join(root, 'lib', 'libdaas.so');

if (process.platform !== 'linux') {
  console.warn('[daas-sdk] Native build skipped: version 0.22.0 currently supports Linux x64 only.');
  process.exit(0);
}

if (process.arch !== 'x64') {
  console.error(`[daas-sdk] Unsupported Linux architecture: ${process.arch}. Expected x64.`);
  process.exit(1);
}

if (!fs.existsSync(libraryPath)) {
  console.error(`[daas-sdk] Missing precompiled library: ${libraryPath}`);
  process.exit(1);
}

const nodeGyp = require.resolve('node-gyp/bin/node-gyp.js');
const result = spawnSync(process.execPath, [nodeGyp, 'rebuild'], {
  cwd: root,
  stdio: 'inherit',
});

if (result.error) {
  console.error('[daas-sdk] Unable to start node-gyp:', result.error.message);
  process.exit(1);
}

process.exit(result.status ?? 1);
