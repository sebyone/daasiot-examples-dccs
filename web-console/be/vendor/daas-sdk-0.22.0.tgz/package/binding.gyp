## shared_library
## static_library
## loadable_module // per nodejs
## executable
## none

{
  "targets": [
    {
      "target_name": "libdaas",
      "include_dirs": [
        "<!@(node -p \"require('node-addon-api').include\")",
        "<(module_root_dir)/lib/include",
        "./include"
      ],
      ## libdaas caricata dinamicamente a runtime tramite DaasLoader::load(path)
      ## — nessun link statico o dinamico a compile-time verso libdaas
      "libraries": [],
      "sources": [
        "./src/daasAPIWrapper.cpp",
        "./src/daas_loader.cpp",
        "./src/daasiot_events.cpp",
        "./src/daasiot_generals.cpp",
        "./src/daasiot_mapping.cpp",
        "./src/daasiot_transfer.cpp",
        "./src/daasjs.cpp",
        "./src/dtojs.cpp"
      ],
      "cflags!":    ["-fno-exceptions"],
      "cflags_cc!": ["-fno-exceptions"],
      "defines": ["NAPI_DISABLE_CPP_EXCEPTIONS"],
      "conditions": [
        ["OS==\"linux\"", {
          "defines": ["LINUX_DEFINE"],
          ## dl è necessario per dlopen/dlsym
          "libraries": ["-ldl"]
        }],
        ["OS==\"mac\"", {
          ## Su macOS dlopen è in libSystem, non serve -ldl
          "libraries": []
        }],
        ["OS==\"win\"", {
          "libraries": [
            "Ws2_32.lib",
            "Bthprops.lib"
          ]
        }]
      ],
      "msvs_settings": {
        "VCLinkerTool":    { "RuntimeLibrary": 4 },
        "VCCLCompilerTool":{ "RuntimeLibrary": 4 }
      },
      "configurations": {
        "Debug":  { "msvs_settings": { "VCCLCompilerTool": { "RuntimeLibrary": 4 } } },
        "Release":{ "msvs_settings": { "VCCLCompilerTool": { "RuntimeLibrary": 3 } } }
      }
    }
  ]
}


## RuntimeLibrary
## 3 = MultiThreadedDLL     (/MD)  — release
## 4 = MultiThreadedDebugDLL (/MDd) — debug
