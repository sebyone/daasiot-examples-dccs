/*
 * DaaS-IoT 2026 (@) Sebyone Srl
 *
 * File: daas_loader.h
 *
 * This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
 * If a copy of the MPL was not distributed with this file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

#ifndef _DAAS_LOADER_H__
#define _DAAS_LOADER_H__

#include <string>

/*
 * Singleton that manages runtime dynamic loading of libdaas.
 *
 * On Linux/macOS uses dlopen(RTLD_NOW | RTLD_GLOBAL) so that the C++ symbols
 * exported by the shared library become available to the whole process and can
 * be resolved by any subsequent DaasAPI construction.
 *
 * On Windows uses LoadLibraryA / SetDllDirectoryA.
 *
 * JS usage:
 *   const { DaasIoT } = require('./build/Release/daas.node');
 *   DaasIoT.loadLibrary('/path/to/libdaas.so');   // must be called first
 *   const node = new DaasIoT('nodeJS');
 */
class DaasLoader
{
public:
    static bool        load(const std::string &path);
    static bool        isLoaded();
    static std::string getPath();
    static std::string getLastError();

    DaasLoader()  = delete;
    ~DaasLoader() = delete;

private:
    static void       *_handle;
    static std::string _path;
    static std::string _lastError;
};

#endif
