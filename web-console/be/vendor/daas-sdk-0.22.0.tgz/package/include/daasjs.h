/*
 * DaaS-IoT 2023, 2026 (@) Sebyone Srl
 *
 * File: daasjs.h
 *
 * This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
 * If a copy of the MPL was not distributed with this file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

#ifndef _DAASJS_H__
#define _DAASJS_H__

#define UNUSED(x) (void)(x)

#include <napi.h>
#include <daas.hpp>
#include <daas_types.hpp>
#include "daas_loader.h"

struct CallbackParams {
    int din;
};

struct PullCallbackParams {
    din_t          origin;
    stime_t        timestamp;
    typeset_t      typeset;
    unsigned char *data;
    size_t         dataLength;
};

struct NetworkDiscoveredParams {
    din_t  din;
    din_t  sid;
    link_t link;
};

class DaasIotJs : public Napi::ObjectWrap<DaasIotJs>, IDaasApiEvent
{
public:
    static Napi::Object Init(Napi::Env env, Napi::Object exports);
    DaasIotJs(const Napi::CallbackInfo &info);
    ~DaasIotJs() {}

private:
    DaasAPI *_daasInstance;

    Napi::ThreadSafeFunction onDINAcceptedEvent;
    Napi::ThreadSafeFunction onDDOReceivedEvent;
    Napi::ThreadSafeFunction onNetworkDiscoveredEvent;
    Napi::ThreadSafeFunction pullDDO;

    void releaseEventCallbacks();

    // Generals
    Napi::Value getVersion(const Napi::CallbackInfo &info);
    Napi::Value  getBuildInfo(const Napi::CallbackInfo &info);
    Napi::Value  doInit(const Napi::CallbackInfo &info);
    Napi::Value  doPerform(const Napi::CallbackInfo &info);
    Napi::Value  getChanges(const Napi::CallbackInfo &info);
    Napi::Value  doReset(const Napi::CallbackInfo &info);
    Napi::Value  getStatus(const Napi::CallbackInfo &info);
    Napi::Value  listAvailableDrivers(const Napi::CallbackInfo &info);
    Napi::Value  enableDriver(const Napi::CallbackInfo &info);
    Napi::Value  setOptions(const Napi::CallbackInfo &info);
    Napi::Value  doStatisticsReset(const Napi::CallbackInfo &info);
    Napi::Value  getSystemStatistics(const Napi::CallbackInfo &info);
    Napi::Value  doEnd(const Napi::CallbackInfo &info);
    Napi::Value  errorToString(const Napi::CallbackInfo &info);
    // Mapping
    Napi::Value  addTypeset(const Napi::CallbackInfo &info);
    Napi::Value  typesetList(const Napi::CallbackInfo &info);
    // Availability
    Napi::Value  listNodes(const Napi::CallbackInfo &info);
    Napi::Value  getNodeList(const Napi::CallbackInfo &info);
    Napi::Value  locate(const Napi::CallbackInfo &info);
    // Network
    Napi::Value  map(const Napi::CallbackInfo &info);
    Napi::Value  remove(const Napi::CallbackInfo &info);
    Napi::Value  discovery(const Napi::CallbackInfo &info);
    Napi::Value  join(const Napi::CallbackInfo &info);
    Napi::Value  setDiscoveryState(const Napi::CallbackInfo &info);
    Napi::Value  createNetwork(const Napi::CallbackInfo &info);
    Napi::Value  unbindNetwork(const Napi::CallbackInfo &info);
    Napi::Value  setAcceptRequestsLevel(const Napi::CallbackInfo &info);
    // Time / Sync
    Napi::Value  setATSMaxError(const Napi::CallbackInfo &info);
    Napi::Value  getSyncedTimestamp(const Napi::CallbackInfo &info);
    // Transfer
    Napi::Value  push(const Napi::CallbackInfo &info);
    Napi::Value  pull(const Napi::CallbackInfo &info);
    Napi::Value  availablesPull(const Napi::CallbackInfo &info);
    Napi::Value  setDDOPolicy(const Napi::CallbackInfo &info);
    // Streaming
    Napi::Value  use(const Napi::CallbackInfo &info);
    Napi::Value  send(const Napi::CallbackInfo &info);
    Napi::Value  received(const Napi::CallbackInfo &info);
    Napi::Value  receive(const Napi::CallbackInfo &info);
    Napi::Value  endStream(const Napi::CallbackInfo &info);
    // Diagnostics
    Napi::Value  frisbee(const Napi::CallbackInfo &info);
    Napi::Value  frisbeeICMP(const Napi::CallbackInfo &info);
    // Node features
    Napi::Value  addNodeFeatures(const Napi::CallbackInfo &info);
    Napi::Value  getNodeFeatures(const Napi::CallbackInfo &info);
    Napi::Value  nodeHasFeature(const Napi::CallbackInfo &info);

    // IDaasApiEvent overrides
    void dinAccepted(din_t) override;
    void ddoReceived(int, typeset_t, din_t) override;
    void frisbeeReceived(din_t) override;
    void nodeStateReceived(din_t) override;
    void atsSyncCompleted(din_t) override;
    void frisbeeDperfCompleted(din_t, uint32_t, uint32_t) override;
    void networkDiscovered(din_t, din_t, link_t) override;
    void nodeConnectedToNetwork(din_t, din_t) override;
    void streamInfoReceived(din_t, stream_type, uint32_t) override;

    // JS event registration
    Napi::Value onDinConnected(const Napi::CallbackInfo &info);
    Napi::Value onDDOReceived(const Napi::CallbackInfo &info);
    Napi::Value onNetworkDiscovered(const Napi::CallbackInfo &info);

    // Static library loader (must be called before new DaasIoT())
    static Napi::Value loadLibrary(const Napi::CallbackInfo &info);
    static Napi::Value isLibraryLoaded(const Napi::CallbackInfo &info);
    static Napi::Value getLibraryPath(const Napi::CallbackInfo &info);
};

#endif
