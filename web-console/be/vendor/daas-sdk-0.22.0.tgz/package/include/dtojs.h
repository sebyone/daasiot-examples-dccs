#ifndef _DTOJS_H__
#define _DTOJS_H__

#include <napi.h>
#include <daas.hpp>
#include <daas_types.hpp>

#include <iostream>
#include <vector>

class Dtojs : public Napi::ObjectWrap<Dtojs> , DDO {

public:

    Napi::FunctionReference onComplete;

    Dtojs(const Napi::CallbackInfo &info) : Napi::ObjectWrap<Dtojs>(info)
    {
        Napi::Env env = info.Env();
        Napi::HandleScope scope(env);
        onComplete = Napi::Persistent(info[0].As<Napi::Function>());
        //this->ref = Reference<Napi::Object>::New(obj);
    }

    Napi::Value make(const Napi::CallbackInfo &info);

    void setTset(const Napi::CallbackInfo &info, const Napi::Value &value)
    {
        //Napi::Env env = info.Env();
        Napi::Number arg = value.As<Napi::Number>();
        //this->_typeset = arg.Uint32Value();
        this->setTypeset(arg.Uint32Value());
    }

    Napi::Value getTset(const Napi::CallbackInfo &info)
    {
        Napi::Env env = info.Env();
        return Napi::Number::New(env, this->getTypeset());
    }

    static Napi::Object Initialize(Napi::Env env, Napi::Object &target) {
        Napi::Value val;
        Napi::Function func = Napi::ObjectWrap<Dtojs>::DefineClass(env, "dtojs", {
        Napi::ObjectWrap<Dtojs>::InstanceMethod("make", &Dtojs::make),
        //Napi::ObjectWrap<Dtojs>::InstanceMethod("create", &Dtojs::make),
        Napi::ObjectWrap<Dtojs>::InstanceAccessor("typeset", &Dtojs::getTset, &Dtojs::setTset)
        });

        Napi::FunctionReference* constructor = new Napi::FunctionReference();
        *constructor = Napi::Persistent(func);
        env.SetInstanceData(constructor);
        target.Set("dtojs", func);
        target.Set("typeset", 3);

        return target;
    }
};

#endif
